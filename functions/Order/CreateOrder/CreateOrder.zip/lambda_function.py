import boto3
import json

def lambda_handler(event, context):
    return {
        "msg": "Deu cert"
    }
