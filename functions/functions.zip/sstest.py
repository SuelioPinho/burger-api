
def print():
    return "Deu certo"
